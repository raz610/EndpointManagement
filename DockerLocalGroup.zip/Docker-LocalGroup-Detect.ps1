if (-not (Test-Path -Path "C:\Program Files\Docker\Docker\Docker Desktop.exe")){
    exit 0;
    }

# Get AzureAD user profiles from C:\Users
$AzureADUsers = Get-ChildItem C:\Users -Directory | Where-Object { 
    ($_.Name -notin @("Public", "defaultuser0", "Administrator")) 
} | ForEach-Object { "AzureAD\$($_.Name)" }

# Get members of the 'docker-users' group
$DockerGroupMembers = (Get-LocalGroupMember -Group 'docker-users').Name

# Check if all AzureAD users are in the 'docker-users' group
if ($AzureADUsers | Where-Object { $DockerGroupMembers -notcontains $_ }) {
    exit 1
} else {
    exit 0
}
