# Get all user directories from C:\Users, excluding system profiles
$AvailableUsers = Get-ChildItem C:\Users -Directory | Where-Object {
    $_.Name -notin @("Public", "defaultuser0", "Default", "All Users")
} | Select-Object -ExpandProperty Name

# Loop through the users and add them to the 'docker-users' group if not already present
foreach ($User in $AvailableUsers) {
    # Define the Azure AD user format
    $AzureAdUser = "azuread\$User"

    # Check if the user is already a member of the group
    $IsMember = Get-LocalGroupMember -Group "docker-users" -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq $AzureAdUser }

    if ($IsMember) {
        Write-Host "User $AzureAdUser is already a member of the docker-users group. Skipping..."
    } else {
        try {
            # Add the user to the 'docker-users' group
            Add-LocalGroupMember -Group "docker-users" -Member $AzureAdUser -ErrorAction Stop
            Write-Host "Successfully added $AzureAdUser to the docker-users group."
        } catch {
            # Handle any errors during group addition
            Write-Warning "Failed to add $AzureAdUser to the docker-users group. Error: $_"
        }
    }
}
