# Get the computer's serial number
$SerialNumber = (Get-WmiObject Win32_BIOS).SerialNumber

# Define the new computer name - Change PC the prefix as needed
$NewComputerName = "PC-$SerialNumber"

# Get the current computer name
$CurrentComputerName = $env:COMPUTERNAME

# Check if the name already matches to avoid unnecessary changes
if ($CurrentComputerName -eq $NewComputerName) {
    Write-Host "Computer name is already set to $NewComputerName. No changes needed."
    exit 0
}

# Rename the computer
Rename-Computer -NewName $NewComputerName -Force

# Prompt for restart
Restart-Computer -Force -Confirm