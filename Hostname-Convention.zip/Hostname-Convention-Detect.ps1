# Get the computer's serial number
$SerialNumber = (Get-WmiObject Win32_BIOS).SerialNumber

# Expected computer name - Change PC to match your naming convention
$ExpectedComputerName = "PC-$SerialNumber"

# Get the current computer name
$CurrentComputerName = $env:COMPUTERNAME

# Check if the computer name matches the expected format
if ($CurrentComputerName -eq $ExpectedComputerName) {
    exit 0  # Compliant
} else {
    exit 1  # Non-compliant
}