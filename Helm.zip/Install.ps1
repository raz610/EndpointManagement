﻿if (![Environment]::GetEnvironmentVariable('path', 'Machine').Contains("C:\Program Files\Helm")){ 

[Environment]::SetEnvironmentVariable( 

    "Path", 

    [Environment]::GetEnvironmentVariable("Path", [EnvironmentVariableTarget]::Machine) + ";C:\Program Files\Helm", 

    [EnvironmentVariableTarget]::Machine) 

} 

mkdir "C:\Program Files\Helm"  

Expand-Archive Helm.zip -DestinationPath "C:\Program Files\Helm"
