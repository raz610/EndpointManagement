﻿# Define the path to the file you want to check
$filePath = "C:\Program Files\Helm\Helm.exe"
$variablePath = "C:\Program Files\Helm\"



if (![Environment]::GetEnvironmentVariable('path', 'Machine').Contains($variablePath)){ 
Write-Output "variable missing";
    exit 1
}

# Check if the file exists
if (-not (Test-Path $filePath -PathType Leaf)) {
    Write-Error "Error: The file '$filePath' does not exist."
    exit 1 
}
Write-Output "good"
    exit 0