try {
    Get-HotFix -Id KB5027397 -ErrorAction Stop
    exit 0  # KB was found
} catch {
    exit 1  # KB was not found
}